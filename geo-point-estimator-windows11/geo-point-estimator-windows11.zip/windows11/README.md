# Geo Point Estimator

Aplicação local em Python puro com interface visual no navegador para estimar a coordenada geográfica de um ponto observado por drone.

## Como executar

```bash
python3 app.py
```

O servidor sobe escutando em `0.0.0.0:8765`, abre o navegador local automaticamente e fica acessível pela rede no IP da máquina hospedeira.

Para acessar de outra máquina, use:

```text
http://<IP-DA-MAQUINA>:8765
```

## Campos

- Latitude e longitude do drone
- Altitude do drone em ASL
- Altitude do terreno em ASL
- Ângulo da câmera
- Azimute da câmera

## Observação

O aplicativo oferece dois modos para o ângulo:

- A partir da vertical
- A partir do horizonte

O cálculo usa fórmula geodésica sobre esfera terrestre, adequada para uso operacional rápido.
