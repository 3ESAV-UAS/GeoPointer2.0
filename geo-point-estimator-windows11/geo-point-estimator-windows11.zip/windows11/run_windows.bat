@echo off
setlocal
cd /d %~dp0
where python >nul 2>nul
if errorlevel 1 (
  echo Python nao encontrado. Instale Python 3.11+ e tente novamente.
  pause
  exit /b 1
)
python app.py
